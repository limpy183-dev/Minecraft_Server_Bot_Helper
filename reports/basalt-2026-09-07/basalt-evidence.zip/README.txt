Basalt farm benchmark evidence, Minecraft 26.2.
Open REPORT.md. Each completed case has end.json; incomplete launches are excluded from summary.json.
Raw ticks.jsonl contains per-tick telemetry; events.json contains observed edits and decisions; routes.csv/json contains route timings/nodes.
World copies and the redundant 43MB offline cell lookup are excluded from this evidence archive.
The final world is installed separately in the Fabric 26.2 Modrinth saves folder; its path is in provenance.json.
The report links to that local world path; all other evidence links are relative within this archive.
No production bot fixes were applied.
